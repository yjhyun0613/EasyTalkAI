document.addEventListener('DOMContentLoaded', () => {
  // ================= 상태 변수 정의 =================
  let currentDocText = '';
  let activeData = null;
  let selectedFile = null;
  let isListening = false;
  let recognition = null;
  let isSpeaking = false;
  let synth = window.speechSynthesis;
  let speechUtterance = null;

  // ================= DOM 요소 선택 =================
  // 공통 및 접근성
  const toggleLargeFontBtn = document.getElementById('toggle-large-font');
  const toggleHighContrastBtn = document.getElementById('toggle-high-contrast');
  const toastEl = document.getElementById('toast');

  // 1단계 입력 화면
  const stepInput = document.getElementById('step-input');
  const docTextarea = document.getElementById('document-textarea');
  const privacyConsent = document.getElementById('privacy-consent');
  const btnAnalyze = document.getElementById('btn-analyze');
  const btnSpeech = document.getElementById('btn-speech-recognition');
  const micIcon = document.getElementById('mic-icon');
  const uploadZone = document.getElementById('upload-zone');
  const fileInput = document.getElementById('file-input');
  const filePreviewInfo = document.getElementById('file-preview-info');
  const exampleButtons = document.querySelectorAll('.btn-example');

  // 2단계 로딩 화면
  const stepProcessing = document.getElementById('step-processing');
  const stepState1 = document.getElementById('step-state-1');
  const stepState2 = document.getElementById('step-state-2');
  const stepState3 = document.getElementById('step-state-3');
  const stepState4 = document.getElementById('step-state-4');

  // 3단계 결과 화면
  const stepResult = document.getElementById('step-result');
  const resultBadge = document.getElementById('result-badge');
  const resultDocTitle = document.getElementById('result-doc-title');
  const resultConclusion = document.getElementById('result-conclusion');
  const resultTasks = document.getElementById('result-tasks');
  const resultDates = document.getElementById('result-dates');
  const resultItems = document.getElementById('result-items');
  const resultWarnings = document.getElementById('result-warnings');
  const resultConfirms = document.getElementById('result-confirms');
  const cardWarningWrapper = document.getElementById('card-warning-wrapper');
  const cardConfirmWrapper = document.getElementById('card-confirm-wrapper');
  
  const btnToggleSource = document.getElementById('btn-toggle-source');
  const sourceViewContainer = document.getElementById('source-view-container');
  
  const btnGoBackTop = document.getElementById('btn-go-back-top');
  const btnReset = document.getElementById('btn-reset');
  const btnTTS = document.getElementById('btn-tts');
  const btnOpenCalendarModal = document.getElementById('btn-open-calendar-modal');
  const btnOpenShareModal = document.getElementById('btn-open-share-modal');

  // 캘린더 모달
  const calendarModal = document.getElementById('calendar-modal');
  const btnCloseCalendar = document.getElementById('btn-close-calendar');
  const calendarForm = document.getElementById('calendar-form');
  const calTitleInput = document.getElementById('cal-title');
  const calDateInput = document.getElementById('cal-date');
  const calTimeInput = document.getElementById('cal-time');
  const calDescInput = document.getElementById('cal-description');
  const calAlarmInput = document.getElementById('cal-alarm');
  const btnCalGoogle = document.getElementById('btn-cal-google');
  const btnCalOutlook = document.getElementById('btn-cal-outlook');
  const btnCalIcs = document.getElementById('btn-cal-ics');

  // 공유 모달
  const shareModal = document.getElementById('share-modal');
  const btnCloseShare = document.getElementById('btn-close-share');
  const sharePreviewContent = document.getElementById('share-preview-content');
  const btnShareKakao = document.getElementById('btn-share-kakao');
  const btnShareCopy = document.getElementById('btn-share-copy');

  // Gemini API Key 설정
  const DEFAULT_GEMINI_KEY = 'AQ.Ab8RN6KknUpcO7voS69J032vbdIr8hXGShyYE4RqBmdO7Hm-vw';
  const geminiApiKeyInput = document.getElementById('gemini-api-key');
  if (geminiApiKeyInput) {
    geminiApiKeyInput.value = localStorage.getItem('gemini-api-key') || DEFAULT_GEMINI_KEY;
    geminiApiKeyInput.addEventListener('input', () => {
      localStorage.setItem('gemini-api-key', geminiApiKeyInput.value.trim());
    });
  }

  // ================= 기능 함수 =================

  // 토스트 알림 띄우기
  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    setTimeout(() => {
      toastEl.classList.remove('show');
    }, 3000);
  }

  // 화면 전환 관리
  function showStep(stepName) {
    [stepInput, stepProcessing, stepResult].forEach(step => {
      step.classList.remove('active');
    });
    
    if (stepName === 'input') {
      stepInput.classList.add('active');
    } else if (stepName === 'processing') {
      stepProcessing.classList.add('active');
    } else if (stepName === 'result') {
      stepResult.classList.add('active');
    }
  }

  // 접근성: 큰 글씨 토글
  toggleLargeFontBtn.addEventListener('click', () => {
    const isLarge = document.body.classList.toggle('large-font');
    toggleLargeFontBtn.setAttribute('aria-pressed', isLarge);
    toggleLargeFontBtn.classList.toggle('active', isLarge);
    showToast(isLarge ? "큰 글씨 모드가 활성화되었습니다." : "일반 글씨 크기로 변경되었습니다.");
  });

  // 접근성: 고대비 토글
  toggleHighContrastBtn.addEventListener('click', () => {
    const isHC = document.body.classList.toggle('high-contrast');
    toggleHighContrastBtn.setAttribute('aria-pressed', isHC);
    toggleHighContrastBtn.classList.toggle('active', isHC);
    showToast(isHC ? "고대비 모드가 활성화되었습니다." : "고대비 모드가 비활성화되었습니다.");
  });

  // ================= 1단계: 입력 화면 로직 =================

  // 입력 활성화 검사 (입력 텍스트가 존재하고, 동의 체크박스가 눌려야 함)
  function checkInputValidity() {
    const textVal = docTextarea.value.trim();
    const isAgreed = privacyConsent.checked;
    btnAnalyze.disabled = !(textVal.length > 0 && isAgreed);
  }

  docTextarea.addEventListener('input', checkInputValidity);
  privacyConsent.addEventListener('change', checkInputValidity);

  // 예시 불러오기 갤러리 클릭 이벤트
  exampleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const docId = btn.getAttribute('data-doc-id');
      const data = mockData[docId];
      if (data) {
        docTextarea.value = data.original_text;
        privacyConsent.checked = true;
        checkInputValidity();
        showToast(`'${data.document_type_label}' 예시 문서를 로드했습니다.`);
      }
    });
  });

  // 드래그앤드롭 파일 업로드 이벤트
  uploadZone.addEventListener('click', () => {
    fileInput.click();
  });

  fileInput.addEventListener('change', (e) => {
    handleFiles(e.target.files);
  });

  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'var(--accent)';
  });

  uploadZone.addEventListener('dragleave', () => {
    uploadZone.style.borderColor = 'var(--border-color)';
  });

  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'var(--border-color)';
    handleFiles(e.dataTransfer.files);
  });

  function handleFiles(files) {
    if (files.length > 0) {
      selectedFile = files[0];
      filePreviewInfo.style.display = 'block';
      filePreviewInfo.innerHTML = `📄 <strong>선택된 파일:</strong> ${selectedFile.name} (${(selectedFile.size/1024).toFixed(1)} KB)`;
      
      // 파일 업로드 시뮬레이션: 파일명에 따라 적합한 mockData 자동 삽입 (디자인 및 시연용)
      const fileName = selectedFile.name.toLowerCase();
      let matchedData = mockData.tax_notice; // default
      let label = "지방세 납부 고지";

      if (fileName.includes('세금') || fileName.includes('tax') || fileName.includes('고지서')) {
        matchedData = mockData.tax_notice;
        label = "지방세 납부 고지";
      } else if (fileName.includes('예비군') || fileName.includes('훈련') || fileName.includes('military') || fileName.includes('reserve')) {
        matchedData = mockData.reserve_forces;
        label = matchedData.document_type_label;
      } else if (fileName.includes('건강') || fileName.includes('검진') || fileName.includes('medical') || fileName.includes('health')) {
        matchedData = mockData.health_checkup;
        label = matchedData.document_type_label;
      } else {
        // 랜덤으로 하나 매핑
        const keys = Object.keys(mockData);
        matchedData = mockData[keys[Math.floor(Math.random() * keys.length)]];
        label = matchedData.document_type_label;
      }

      docTextarea.value = matchedData.original_text;
      privacyConsent.checked = true;
      checkInputValidity();
      showToast(`'${selectedFile.name}' 파일 인식 성공: '${label}' 데이터를 매핑했습니다.`);
    }
  }

  // Web Speech API: 음성 입력(STT)
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'ko-KR';
    recognition.interimResults = false;

    recognition.onstart = () => {
      isListening = true;
      btnSpeech.classList.add('listening');
      micIcon.textContent = '🛑';
      showToast("마이크 음성 인식을 시작합니다. 말씀해 주세요...");
    };

    recognition.onerror = (event) => {
      console.error(event);
      showToast("음성 인식 중 오류가 발생했습니다: " + event.error);
      stopListening();
    };

    recognition.onend = () => {
      stopListening();
    };

    recognition.onresult = (event) => {
      const speechToText = event.results[0][0].transcript;
      docTextarea.value = (docTextarea.value + ' ' + speechToText).trim();
      checkInputValidity();
      showToast("음성 입력이 완료되었습니다.");
    };
  } else {
    btnSpeech.addEventListener('click', () => {
      showToast("죄송합니다. 현재 브라우저는 음성 인식(STT) 기능을 지원하지 않습니다. Chrome 브라우저를 권장합니다.");
    });
  }

  function startListening() {
    if (recognition) {
      try {
        recognition.start();
      } catch (e) {
        console.error(e);
      }
    }
  }

  function stopListening() {
    isListening = false;
    btnSpeech.classList.remove('listening');
    micIcon.textContent = '🎤';
    if (recognition) {
      try {
        recognition.stop();
      } catch (e) {
        // 이미 중단된 상태면 에러 무시
      }
    }
  }

  if (SpeechRecognition) {
    btnSpeech.addEventListener('click', () => {
      if (isListening) {
        stopListening();
      } else {
        startListening();
      }
    });
  }

  // ================= 텍스트 기반 다이내믹 요약 생성기 (OCR 지원용) =================
  function generateDynamicData(text) {
    // 1. 날짜 추출 시도
    const dates = [];
    const dateRegex = /(\d{4})[.-](\d{1,2})[.-](\d{1,2})|(\d{1,2})월\s*(\d{1,2})일/g;
    let match;
    let count = 0;
    const currentYear = new Date().getFullYear();
    while ((match = dateRegex.exec(text)) !== null && count < 3) {
      let year = currentYear;
      let month = '';
      let day = '';
      
      if (match[1]) { // YYYY-MM-DD 형태
        year = match[1];
        month = String(match[2]).padStart(2, '0');
        day = String(match[3]).padStart(2, '0');
      } else if (match[4]) { // MM월 DD일 형태
        month = String(match[4]).padStart(2, '0');
        day = String(match[5]).padStart(2, '0');
      }
      
      if (month && day) {
        dates.push({
          date: `${year}-${month}-${day}`,
          time: "18:00",
          type: "deadline",
          label: `문서 기재 날짜 (${month}/${day})`
        });
        count++;
      }
    }
    
    if (dates.length === 0) {
      // 기본 날짜 하나 추가 (7일 뒤)
      const futureDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const y = futureDate.getFullYear();
      const m = String(futureDate.getMonth() + 1).padStart(2, '0');
      const d = String(futureDate.getDate()).padStart(2, '0');
      dates.push({
        date: `${y}-${m}-${d}`,
        time: "18:00",
        type: "deadline",
        label: "일정 및 서류 확인 마감"
      });
    }

    // 2. 문장 분리하여 해야할 일 찾기
    const sentences = text.split(/[.\n]/);
    const tasks = [];
    sentences.forEach(s => {
      const clean = s.trim();
      if (clean.length > 5 && tasks.length < 3) {
        if (clean.includes('바랍니다') || clean.includes('요망') || clean.includes('제출') || clean.includes('하십시오') || clean.includes('필요') || clean.includes('안내') || clean.includes('참석') || clean.includes('납부')) {
          tasks.push(clean);
        }
      }
    });

    if (tasks.length === 0) {
      tasks.push("추출된 원문 텍스트 내용을 바탕으로 기한 및 상세 제출 정보를 재확인합니다.");
      tasks.push("문서에 기재된 문의처 또는 담당 기관에 연락하여 상세 내용을 확인합니다.");
    } else if (tasks.length < 3) {
      tasks.push("관련 구비 서류(신분증 등)가 있는지 최종 확인합니다.");
    }

    // 3. 한 줄 요약 만들기
    let summary = "업로드해주신 문서의 텍스트가 추출되었습니다. 상세 일정과 행동 체크리스트를 확인하세요.";
    // 가장 긴 적당한 첫 문장을 요약으로 선정
    for (let i = 0; i < sentences.length; i++) {
      const clean = sentences[i].trim();
      if (clean.length > 12 && clean.length < 100) {
        summary = clean;
        break;
      }
    }

    return {
      document_type: "general_document",
      document_type_label: "기타 행정 문서",
      one_line_conclusion: summary,
      easy_summary: "AI가 이미지에서 읽은 텍스트를 요약한 리포트입니다. 원문 대조 기능을 통해 정확성을 확인해 보세요.",
      tasks: tasks,
      important_dates: dates,
      required_items: ["신분증 및 관련 안내 서류"],
      warnings: [
        "문자 판독(OCR) 결과는 원본 이미지 화질과 상태에 따라 오차가 있을 수 있으므로 주요 날짜와 제출처는 원문을 더블체크 하세요."
      ],
      needs_confirmation: [
        "제출 기한 및 자격 요건에 대한 상세 의문 사항은 문서 하단에 기재된 담당 부서 연락처로 문의하시기 바랍니다."
      ],
      original_text: text
    };
  }

  // Gemini 1.5 Flash 실시간 API 호출 함수
  async function analyzeWithGemini(text, apiKey) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    
    const systemPrompt = `당신은 복잡하고 어려운 공문서, 통지서, 고지서의 텍스트를 분석하여, 어르신이나 디지털 취약계층이 이해하기 쉬운 말로 요약하고 일정을 추출해 주는 "쉽게말해 AI" 비서입니다.
반드시 아래 JSON 스키마 구조로만 답변하세요. 마크다운 백틱(\`\`\`json) 기호 없이 순수 JSON 문자열만 반환해야 합니다.

{
  "document_type_label": "문서 종류 한글 분류 (예: 자동차세 고지서)",
  "one_line_conclusion": "가장 중요한 핵심 결론 한 줄 (쉬운 존댓말)",
  "tasks": ["해야 할 일 조치 사항 1", "해야 할 일 조치 사항 2"],
  "important_dates": [
    {
      "label": "일정의 이름 (예: 납부 마감)",
      "type": "deadline",
      "date": "YYYY-MM-DD",
      "time": "HH:MM"
    }
  ],
  "required_items": ["준비물 1"],
  "warnings": ["불이익이나 가산금 정보 등 주요 주의사항 1"],
  "needs_confirmation": ["문의처 또는 추가 확인 사항 1"],
  "easy_summary": "전반적인 내용에 대한 아주 친절하고 쉬운 구어체 요약 설명"
}`;

    const requestBody = {
      contents: [
        {
          parts: [
            { text: `시스템 안내 및 스키마:\n${systemPrompt}\n\n분석할 실제 문서 본문:\n${text}` }
          ]
        }
      ],
      generationConfig: {
        responseMimeType: "application/json"
      }
    };

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || "네트워크 상태나 키 오류");
    }

    const resData = await response.json();
    const jsonText = resData.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!jsonText) {
      throw new Error("요약 텍스트를 반환받지 못했습니다.");
    }

    const parsedData = JSON.parse(jsonText.trim());
    return {
      document_type: "gemini_analyzed",
      document_type_label: parsedData.document_type_label || "AI 분석 문서",
      one_line_conclusion: parsedData.one_line_conclusion || "핵심 요약을 생성하지 못했습니다.",
      easy_summary: parsedData.easy_summary || "상세 요약 설명 없음",
      tasks: parsedData.tasks || [],
      important_dates: parsedData.important_dates || [],
      required_items: parsedData.required_items || [],
      warnings: parsedData.warnings || [],
      needs_confirmation: parsedData.needs_confirmation || [],
      original_text: text
    };
  }

  // ================= 2단계: 분석 진행 시뮬레이션 및 API 연결 =================
  btnAnalyze.addEventListener('click', () => {
    currentDocText = docTextarea.value.trim();
    const apiKey = (geminiApiKeyInput ? geminiApiKeyInput.value.trim() : '') || DEFAULT_GEMINI_KEY;
    showStep('processing');
    stopSpeech(); // 혹시 돌고 있는 TTS 중단

    // 단계별 진행 상태 초기화
    const states = [stepState1, stepState2, stepState3, stepState4];
    states.forEach(state => {
      state.classList.remove('active', 'completed');
    });

    // 단계별 순차 진행 시뮬레이션
    setTimeout(() => {
      stepState1.classList.add('completed');
      stepState2.classList.add('active');
    }, 600);

    setTimeout(() => {
      stepState2.classList.replace('active', 'completed');
      stepState3.classList.add('active');
    }, 1400);

    setTimeout(() => {
      stepState3.classList.replace('active', 'completed');
      stepState4.classList.add('active');
    }, 2200);

    setTimeout(async () => {
      stepState4.classList.replace('active', 'completed');
      
      let selectedData = null;
      if (apiKey) {
        try {
          selectedData = await analyzeWithGemini(currentDocText, apiKey);
          showToast("✨ Gemini AI가 실시간으로 분석을 완료했습니다.");
        } catch (e) {
          console.error(e);
          showToast(`❌ Gemini API 오류 (${e.message}). 시뮬레이터 모드로 대체합니다.`);
          selectedData = runMockSimulator(currentDocText);
        }
      } else {
        selectedData = runMockSimulator(currentDocText);
      }
      
      activeData = selectedData;
      renderResult(activeData);
      showStep('result');
    }, 3000);
  });

  function runMockSimulator(text) {
    if (text.includes('예비군') || text.includes('훈련') || text.includes('전투복')) {
      return mockData.reserve_forces;
    } else if (text.includes('건강검진') || text.includes('건강검진법') || text.includes('금식')) {
      return mockData.health_checkup;
    } else if (text.includes('자동차세') || text.includes('지방세법') || text.includes('위택스')) {
      return mockData.tax_notice;
    } else {
      // 단어 미매핑 시 다이내믹 요약기 실행
      return generateDynamicData(text);
    }
  }

  // ================= 3단계: 결과 화면 렌더링 =================

  function renderResult(data) {
    // 헤더/분류 설정
    resultBadge.textContent = data.document_type_label;
    resultDocTitle.textContent = `${data.document_type_label} 분석 요약 리포트`;
    
    // 한 줄 결론
    resultConclusion.textContent = data.one_line_conclusion;

    // 할 일 (체크리스트) 동적 생성
    resultTasks.innerHTML = '';
    data.tasks.forEach((task, idx) => {
      const todoItem = document.createElement('div');
      todoItem.className = 'todo-item';
      
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'todo-checkbox';
      checkbox.id = `task-${idx}`;
      
      const label = document.createElement('label');
      label.className = 'todo-text';
      label.htmlFor = `task-${idx}`;
      label.textContent = task;
      
      todoItem.appendChild(checkbox);
      todoItem.appendChild(label);
      
      // 체크 토글 인터랙션
      todoItem.addEventListener('click', (e) => {
        if (e.target !== checkbox) {
          checkbox.checked = !checkbox.checked;
        }
        todoItem.classList.toggle('checked', checkbox.checked);
      });
      
      resultTasks.appendChild(todoItem);
    });

    // 중요 일정 (날짜) 동적 생성
    resultDates.innerHTML = '';
    data.important_dates.forEach(dateObj => {
      const li = document.createElement('li');
      li.className = 'detail-item';
      
      const labelSpan = document.createElement('span');
      labelSpan.className = 'detail-label';
      labelSpan.textContent = dateObj.label;
      
      const valDiv = document.createElement('div');
      
      const badge = document.createElement('span');
      badge.className = 'badge-date';
      badge.style.marginRight = '8px';
      badge.textContent = dateObj.type === 'deadline' ? '마감일' : '일정';
      
      const timeText = document.createTextNode(`${dateObj.date} ${dateObj.time}`);
      
      valDiv.appendChild(badge);
      valDiv.appendChild(timeText);
      li.appendChild(labelSpan);
      li.appendChild(valDiv);
      
      resultDates.appendChild(li);
    });

    // 준비물 동적 생성
    resultItems.innerHTML = '';
    if (data.required_items && data.required_items.length > 0) {
      data.required_items.forEach(item => {
        const li = document.createElement('li');
        li.className = 'detail-item';
        
        const span = document.createElement('span');
        span.className = 'detail-value';
        span.textContent = `• ${item}`;
        
        li.appendChild(span);
        resultItems.appendChild(li);
      });
    } else {
      const li = document.createElement('li');
      li.className = 'detail-item';
      li.innerHTML = '<span class="detail-label" style="color: var(--text-muted);">필요한 준비물이 특별히 없습니다.</span>';
      resultItems.appendChild(li);
    }

    // 주의사항 동적 생성
    resultWarnings.innerHTML = '';
    if (data.warnings && data.warnings.length > 0) {
      cardWarningWrapper.style.display = 'block';
      data.warnings.forEach(warn => {
        const div = document.createElement('div');
        div.className = 'warning-item';
        div.textContent = warn;
        resultWarnings.appendChild(div);
      });
    } else {
      cardWarningWrapper.style.display = 'none';
    }

    // 추가 확인 동적 생성
    resultConfirms.innerHTML = '';
    if (data.needs_confirmation && data.needs_confirmation.length > 0) {
      cardConfirmWrapper.style.display = 'block';
      data.needs_confirmation.forEach(conf => {
        const div = document.createElement('div');
        div.className = 'info-item';
        div.textContent = conf;
        resultConfirms.appendChild(div);
      });
    } else {
      cardConfirmWrapper.style.display = 'none';
    }

    // 아코디언 원문 텍스트 매핑 렌더링
    // 원본 핵심 키워드 매핑 시각화를 위해 원문에 하이라이트 태그 추가 시뮬레이션
    let highlightedText = data.original_text;
    
    // 주요 날짜 강조
    data.important_dates.forEach(d => {
      const dateString = d.date.replace(/-/g, '.'); // 2026.06.30 형태 변환 매핑
      const altDateStr = d.date; // 2026-06-30
      highlightedText = highlightedText.replace(dateString, `<mark class="highlight-source">${dateString}</mark>`);
      highlightedText = highlightedText.replace(altDateStr, `<mark class="highlight-source">${altDateStr}</mark>`);
    });

    // "3%", "가산금", "전투복", "금식" 등 키워드 하이라이트
    const keywords = ["3%", "가산금", "전투복", "군복", "신분증", "입소가 불가", "지각", "금식", "오후 9시 이후부터는 금식", "이중 납부", "이중 출금"];
    keywords.forEach(kw => {
      const regex = new RegExp(kw, 'g');
      highlightedText = highlightedText.replace(regex, `<mark class="highlight-source">${kw}</mark>`);
    });

    sourceViewContainer.innerHTML = highlightedText;
    
    // 닫힌 상태로 초기화
    sourceViewContainer.classList.remove('active');
    btnToggleSource.innerHTML = `<span>🔎</span> 원래 쓰여있던 글(원문)과 비교해보기 (열기)`;
  }

  // 원문 보기 아코디언 토글
  btnToggleSource.addEventListener('click', () => {
    const isActive = sourceViewContainer.classList.toggle('active');
    btnToggleSource.innerHTML = isActive 
      ? `<span>🔎</span> 원래 쓰여있던 글(원문)과 비교해보기 (닫기)`
      : `<span>🔎</span> 원래 쓰여있던 글(원문)과 비교해보기 (열기)`;
  });

  // 다시 입력하기 / 처음으로 가기
  function resetInput() {
    docTextarea.value = '';
    privacyConsent.checked = false;
    fileInput.value = '';
    selectedFile = null;
    filePreviewInfo.style.display = 'none';
    checkInputValidity();
    stopSpeech();
    showStep('input');
  }

  btnGoBackTop.addEventListener('click', resetInput);
  btnReset.addEventListener('click', resetInput);

  // ================= Web Speech API: 음성 합성 (TTS) =================
  function speakText(text) {
    if (!synth) {
      showToast("이 브라우저는 음성 출력을 지원하지 않습니다.");
      return;
    }
    
    stopSpeech();
    
    speechUtterance = new SpeechSynthesisUtterance(text);
    speechUtterance.lang = 'ko-KR';
    speechUtterance.rate = 0.95; // 디지털 약자를 위해 약간 천천히 읽기

    speechUtterance.onstart = () => {
      isSpeaking = true;
      btnTTS.classList.add('btn-action-primary');
      btnTTS.querySelector('.action-icon').textContent = '⏹️';
      btnTTS.querySelector('span:not(.action-icon)').textContent = '읽기 중단';
    };

    speechUtterance.onend = () => {
      isSpeaking = false;
      btnTTS.classList.remove('btn-action-primary');
      btnTTS.querySelector('.action-icon').textContent = '🔊';
      btnTTS.querySelector('span:not(.action-icon)').textContent = '읽어주기 (TTS)';
    };

    speechUtterance.onerror = (e) => {
      console.error(e);
      isSpeaking = false;
    };

    synth.speak(speechUtterance);
  }

  function stopSpeech() {
    if (synth && synth.speaking) {
      synth.cancel();
    }
    isSpeaking = false;
    btnTTS.classList.remove('btn-action-primary');
    btnTTS.querySelector('.action-icon').textContent = '🔊';
    btnTTS.querySelector('span:not(.action-icon)').textContent = '읽어주기 (TTS)';
  }

  btnTTS.addEventListener('click', () => {
    if (isSpeaking) {
      stopSpeech();
      showToast("음성 읽기를 중단했습니다.");
    } else {
      if (!activeData) return;
      
      // 또렷하게 정리하여 읽기 대본 작성
      let speakScript = `신속 요약해 드립니다. 문서 분류는 ${activeData.document_type_label} 입니다. `;
      speakScript += `핵심 결론은 다음과 같습니다. ${activeData.one_line_conclusion} `;
      
      speakScript += `꼭 하셔야 할 일은 다음 몇 가지입니다. `;
      activeData.tasks.forEach((t, i) => {
        speakScript += `${i + 1}번, ${t}. `;
      });

      if (activeData.warnings && activeData.warnings.length > 0) {
        speakScript += `특히 조심하셔야 할 사항도 있습니다. `;
        activeData.warnings.forEach(w => {
          speakScript += `${w}. `;
        });
      }
      
      speakScript += "이상입니다.";
      speakText(speakScript);
    }
  });

  // ================= 캘린더 등록 모달 제어 =================
  btnOpenCalendarModal.addEventListener('click', () => {
    if (!activeData) return;
    
    // 모달 폼 초기 정보 세팅
    const mainDate = activeData.important_dates[0] || { date: '2026-07-02', time: '12:00', label: '주요 일정' };
    
    calTitleInput.value = `[쉽게말해] ${mainDate.label}`;
    calDateInput.value = mainDate.date;
    calTimeInput.value = mainDate.time;
    
    let desc = `[쉽게말해 요약결과]\n- 핵심 내용: ${activeData.one_line_conclusion}\n\n[해야할 일]\n`;
    activeData.tasks.forEach((t, i) => {
      desc += `${i+1}. ${t}\n`;
    });
    if (activeData.required_items && activeData.required_items.length > 0) {
      desc += `\n[준비물]: ${activeData.required_items.join(', ')}\n`;
    }
    
    calDescInput.value = desc;
    
    calendarModal.classList.add('active');
  });

  function closeCalendarModal() {
    calendarModal.classList.remove('active');
  }

  btnCloseCalendar.addEventListener('click', closeCalendarModal);
  
  // 모달 영역 바깥 클릭 시 닫기
  calendarModal.addEventListener('click', (e) => {
    if (e.target === calendarModal) closeCalendarModal();
  });

  // 캘린더 변환 데이터 유틸리티
  function getEventDetails() {
    const title = calTitleInput.value;
    const dateVal = calDateInput.value;
    const timeVal = calTimeInput.value;
    const description = calDescInput.value;
    
    // 날짜 포맷 변환 (YYYYMMDDTHHmmSS)
    const ymd = dateVal.replace(/-/g, '');
    const hm = timeVal.replace(/:/g, '');
    const dtStart = `${ymd}T${hm}00`;
    
    // 마감 기한은 보통 30분 정도 기본 설정
    const startDt = new Date(`${dateVal}T${timeVal}`);
    const endDt = new Date(startDt.getTime() + 30 * 60 * 1000);
    const endYmd = endDt.getFullYear() + String(endDt.getMonth()+1).padStart(2, '0') + String(endDt.getDate()).padStart(2, '0');
    const endHm = String(endDt.getHours()).padStart(2, '0') + String(endDt.getMinutes()).padStart(2, '0');
    const dtEnd = `${endYmd}T${endHm}00`;

    return {
      title,
      dtStart,
      dtEnd,
      description
    };
  }

  // 구글 캘린더 등록
  btnCalGoogle.addEventListener('click', () => {
    const ev = getEventDetails();
    const googleUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(ev.title)}&dates=${ev.dtStart}/${ev.dtEnd}&details=${encodeURIComponent(ev.description)}&sf=true`;
    
    window.open(googleUrl, '_blank');
    closeCalendarModal();
    showToast("구글 캘린더 등록 페이지로 이동합니다.");
  });

  // 아웃룩 캘린더 등록
  btnCalOutlook.addEventListener('click', () => {
    const ev = getEventDetails();
    // Outlook Live ISO Format 변환
    const startIso = `${calDateInput.value}T${calTimeInput.value}:00`;
    
    const startDt = new Date(`${calDateInput.value}T${calTimeInput.value}`);
    const endDt = new Date(startDt.getTime() + 30 * 60 * 1000);
    const endIso = endDt.toISOString().substring(0, 19);

    const outlookUrl = `https://outlook.live.com/calendar/0/deeplink/compose?path=/calendar/action/compose&rru=addevent&subject=${encodeURIComponent(ev.title)}&startdt=${startIso}&enddt=${endIso}&body=${encodeURIComponent(ev.description)}`;
    
    window.open(outlookUrl, '_blank');
    closeCalendarModal();
    showToast("아웃룩 캘린더 등록 페이지로 이동합니다.");
  });

  // ICS 파일 다운로드
  btnCalIcs.addEventListener('click', () => {
    const ev = getEventDetails();
    
    const icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//EasilySayAI//CalendarEvent//KO",
      "BEGIN:VEVENT",
      `SUMMARY:${ev.title}`,
      `DTSTART:${ev.dtStart}`,
      `DTEND:${ev.dtEnd}`,
      `DESCRIPTION:${ev.description.replace(/\n/g, '\\n')}`,
      "END:VEVENT",
      "END:VCALENDAR"
    ].join("\r\n");

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${ev.title.replace(/[\[\]]/g, '')}_일정.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    closeCalendarModal();
    showToast("표준 캘린더 파일(.ics)을 다운로드했습니다. 캘린더 앱에서 불러오실 수 있습니다.");
  });

  // ================= 보호자 공유 모달 제어 =================
  btnOpenShareModal.addEventListener('click', () => {
    if (!activeData) return;

    // 공유 텍스트 빌드
    let previewText = `[쉽게말해 AI 요약 본 공유]\n`;
    previewText += `📋 문서: ${activeData.document_type_label}\n\n`;
    previewText += `📌 핵심 한줄요약:\n${activeData.one_line_conclusion}\n\n`;
    
    const d = activeData.important_dates[0];
    if (d) {
      previewText += `📅 주요 일정:\n- ${d.label}: ${d.date} ${d.time}\n\n`;
    }

    previewText += `✅ 해야할 일:\n`;
    activeData.tasks.forEach((t, i) => {
      previewText += `${i+1}. ${t}\n`;
    });

    if (activeData.required_items && activeData.required_items.length > 0) {
      previewText += `\n🎒 준비물: ${activeData.required_items.join(', ')}\n`;
    }
    
    if (activeData.warnings && activeData.warnings.length > 0) {
      previewText += `\n⚠️ 주의사항: ${activeData.warnings[0]}\n`;
    }

    sharePreviewContent.textContent = previewText;
    shareModal.classList.add('active');
  });

  function closeShareModal() {
    shareModal.classList.remove('active');
  }

  btnCloseShare.addEventListener('click', closeShareModal);
  
  shareModal.addEventListener('click', (e) => {
    if (e.target === shareModal) closeShareModal();
  });

  // 안드로이드 네이티브 앱 연동 확인 변수 (window 객체 안전 검사)
  const isAndroidApp = typeof window.EasyTalkAINative !== 'undefined';
  let sharedFilesList = []; // 공유된 파일 목록 보관용 변수

  // 안드로이드로부터 공유받은 페이로드(텍스트 및 파일) 통합 처리 함수
  function handleSharedPayload(payload) {
    if (!payload) return;

    // 1. 텍스트 추출 및 적재
    if (payload.text) {
      docTextarea.value = payload.text;
    }

    // 2. 파일 목록 추출 및 UI 표시
    if (payload.files && payload.files.length > 0) {
      sharedFilesList = payload.files;
      filePreviewInfo.style.display = 'block';
      
      const fileListHtml = payload.files.map(f => 
        `<li>📄 <strong>${f.name}</strong> (${f.sizeText})</li>`
      ).join('');
      
      filePreviewInfo.innerHTML = `
        <div style="text-align: left; margin-bottom: 8px; font-weight: 700;">📥 공유된 파일 (${payload.files.length}개):</div>
        <ul style="list-style: none; padding-left: 0; display: flex; flex-direction: column; gap: 6px; text-align: left;">
          ${fileListHtml}
        </ul>
      `;
    } else {
      sharedFilesList = [];
    }

    privacyConsent.checked = true;
    checkInputValidity();
  }

  // 카카오톡 전송 시뮬레이션 및 네이티브 공유 인터셉트
  btnShareKakao.addEventListener('click', () => {
    const textToCopy = sharePreviewContent.textContent;
    if (isAndroidApp && typeof window.EasyTalkAINative.shareText === 'function') {
      try {
        window.EasyTalkAINative.shareText("쉽게말해 AI 정리 결과", textToCopy);
        closeShareModal();
      } catch (e) {
        console.error(e);
        closeShareModal();
        showToast("💬 공유하기 중 오류가 발생했습니다.");
      }
    } else {
      closeShareModal();
      showToast("💬 카카오톡 전송 링크를 연결했습니다. (보호자에게 전송 완료)");
    }
  });

  // 클립보드 복사 및 네이티브 복사 인터셉트
  btnShareCopy.addEventListener('click', () => {
    const textToCopy = sharePreviewContent.textContent;
    if (isAndroidApp && window.EasyTalkAINative && typeof window.EasyTalkAINative.copyText === 'function') {
      try {
        window.EasyTalkAINative.copyText("쉽게말해 AI 요약 결과", textToCopy);
        closeShareModal();
        showToast("📋 앱 클립보드에 복사되었습니다.");
      } catch (e) {
        console.error(e);
        fallbackCopy(textToCopy);
      }
    } else {
      fallbackCopy(textToCopy);
    }
  });

  function fallbackCopy(text) {
    navigator.clipboard.writeText(text).then(() => {
      closeShareModal();
      showToast("📋 요약 내용이 클립보드에 복사되었습니다. 보호자 채팅방에 붙여넣기(Ctrl+V) 하세요.");
    }).catch(err => {
      console.error(err);
      showToast("클립보드 복사에 실패했습니다. 직접 복사해 주세요.");
    });
  }

  // 안드로이드 네이티브 캘린더 등록 UI 전환 및 처리
  const btnCalNative = document.getElementById('btn-cal-native');
  const webCalendarActions = document.getElementById('web-calendar-actions');

  if (isAndroidApp && btnCalNative && webCalendarActions) {
    btnCalNative.style.display = 'flex';
    webCalendarActions.style.display = 'none';

    btnCalNative.addEventListener('click', () => {
      const ev = getEventDetails();
      const startDt = new Date(`${calDateInput.value}T${calTimeInput.value}`);
      const endDt = new Date(startDt.getTime() + 30 * 60 * 1000); // 30분 기한 설정

      if (window.EasyTalkAINative && typeof window.EasyTalkAINative.addCalendarEvent === 'function') {
        try {
          window.EasyTalkAINative.addCalendarEvent(
            ev.title,
            String(startDt.getTime()), // 밀리초 타임스탬프 문자열 전송
            String(endDt.getTime()),
            ev.description,
            "" // 위치 (공백 처리)
          );
          closeCalendarModal();
          showToast("📱 스마트폰 캘린더에 일정을 저장했습니다.");
        } catch (e) {
          console.error(e);
          showToast("캘린더 저장 중 오류가 발생했습니다.");
        }
      }
    });
  }

  // 안드로이드로부터 외부 공유 페이로드(문자/파일 등) 수신 리스너 등록
  window.EasyTalkAI = window.EasyTalkAI || {};
  window.EasyTalkAI.receiveSharedPayload = function(payload) {
    handleSharedPayload(payload);
    showToast("공유된 데이터를 가져왔습니다.");
  };

  window.addEventListener("easyTalkAISharedPayload", function(event) {
    const payload = event.detail;
    handleSharedPayload(payload);
    showToast("공유된 데이터를 가져왔습니다.");
  });

  // 시작 시 localStorage 캐시 데이터 수신 확인
  const cachedSharedText = localStorage.getItem("easyTalkAI.sharedText");
  const cachedSharedFilesJson = localStorage.getItem("easyTalkAI.sharedFiles");
  if (cachedSharedText || cachedSharedFilesJson) {
    const payload = {
      text: cachedSharedText || "",
      files: cachedSharedFilesJson ? JSON.parse(cachedSharedFilesJson) : []
    };
    handleSharedPayload(payload);
    showToast("공유된 데이터를 불러왔습니다.");
    
    // 로컬 스토리지 초기화
    localStorage.removeItem("easyTalkAI.sharedText");
    localStorage.removeItem("easyTalkAI.sharedFiles");
  }

  // 서비스 워커 등록
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js')
      .then(reg => console.log('Service Worker registered successfully from app.js', reg))
      .catch(err => console.error('Service Worker registration failed from app.js', err));
  }

  // 초기 상태 로드
  checkInputValidity();
});
