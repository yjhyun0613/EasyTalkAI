const CACHE_NAME = 'easily-say-ai-cache-v1';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './demo.html',
  './style.css',
  './app.js',
  './mockData.js',
  './manifest.json',
  './app_icon.png'
];

// 서비스 워커 설치 시 자원 캐싱
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    }).then(() => self.skipWaiting())
  );
});

// 서비스 워커 활성화
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// 네트워크 요청 캐시 매칭 및 패치
self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((cachedResponse) => {
      return cachedResponse || fetch(e.request).catch(() => {
        // 네트워크가 끊겼을 때 캐시에서 index.html 반환 (오프라인 지원)
        if (e.request.mode === 'navigate') {
          return caches.match('./index.html');
        }
      });
    })
  );
});
